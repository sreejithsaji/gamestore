from django.shortcuts import render,redirect

from django.views.generic import View,TemplateView

from todo.forms import SignUpForm,SignInForm,TaskForm

from django.contrib.auth import authenticate,login

from todo.models import Task


class SignupView(View):

    def get(self,request,*args,**kwargs):

        form_instance=SignUpForm()

        return render(request,'register.html',{"form":form_instance})
    
    def post(self,request,*args,**kwargs):

        form_instance=SignUpForm(request.POST)

        if form_instance.is_valid():

            form_instance.save()

            return redirect("signin")
        
        else:
            
            return render(request,'register.html',{"form":form_instance})


class SignInView(View):

    def get(self,request,*args,**kwargs):

        form_instance=SignInForm()

        return render(request,'login.html',{"form":form_instance})

    def post(self,request,*args,**kwargs):

        form_instance=SignInForm(request.POST)

        if form_instance.is_valid():
            
            data=form_instance.cleaned_data

            user_obj=authenticate(request,**data)

            if user_obj:

                login(request,user_obj)

                return redirect("task-add")

        return render(request,"login.html",{'form':form_instance})    
        

class IndexView(TemplateView):

    template_name="index.html"


class  TaskCreateView(View):

    def get(self,request,*args,**kwargs):

        form_instance=TaskForm()

        return render(request,'task_add.html',{"form":form_instance})
    
    def post(self,request,*args,**kwargs):

        form_instance=TaskForm(request.POST)

        if form_instance.is_valid():

            form_instance.instance.owner=request.user

            form_instance.save()

            return redirect("task-add")
        
        else:

            return render(request,'task_add.html',{"form":form_instance})



class TaskUpdateView(View):

    def get(self,request,*args,**kwargs):
        
               

    
            